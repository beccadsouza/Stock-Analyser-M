create view view_2 as
  select
    `hotel_vortex_south`.`orders`.`order_id`        AS `order_id`,
    `hotel_vortex_south`.`orders`.`item_id`         AS `item_id`,
    `hotel_vortex_south`.`orders`.`no_items`        AS `no_items`,
    `hotel_vortex_south`.`orders`.`customer_id`     AS `customer_id`,
    `hotel_vortex_south`.`orders`.`bill_id`         AS `bill_id`,
    `hotel_vortex_south`.`orders`.`order_timestamp` AS `order_timestamp`
  from `hotel_vortex_south`.`orders`
  where (cast(`hotel_vortex_south`.`orders`.`order_timestamp` as date) > '2017-11-10');

