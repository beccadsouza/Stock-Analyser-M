create view query_9 as
  select
    `hotel_vortex_south`.`customer`.`customer_id` AS `customer_id`,
    `hotel_vortex_south`.`customer`.`name`        AS `name`,
    `hotel_vortex_south`.`customer`.`table_id`    AS `table_id`,
    `hotel_vortex_south`.`orders`.`no_items`      AS `no_items`
  from (`hotel_vortex_south`.`orders`
    join `hotel_vortex_south`.`customer`
      on ((`hotel_vortex_south`.`customer`.`customer_id` = `hotel_vortex_south`.`orders`.`customer_id`)))
  where (`hotel_vortex_south`.`orders`.`no_items` > 5);

