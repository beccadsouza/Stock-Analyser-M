create view view_1 as
  select `hotel_vortex_south`.`customer`.`name` AS `name`
  from (`hotel_vortex_south`.`customer`
    join `hotel_vortex_south`.`tables` on ((
      (`hotel_vortex_south`.`customer`.`table_id` = `hotel_vortex_south`.`tables`.`table_id`) and
      (`hotel_vortex_south`.`tables`.`seating` = 6) and (`hotel_vortex_south`.`customer`.`name` like '%i'))));

