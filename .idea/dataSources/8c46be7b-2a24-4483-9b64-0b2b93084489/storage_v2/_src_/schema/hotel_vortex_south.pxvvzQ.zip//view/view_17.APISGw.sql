create view view_17 as
  select
    `hotel_vortex_south`.`bill`.`bill_id`    AS `bill_id`,
    `hotel_vortex_south`.`bill`.`mode_pay`   AS `mode_pay`,
    `hotel_vortex_south`.`bill`.`tot_amount` AS `tot_amount`
  from `hotel_vortex_south`.`bill`
  where (`hotel_vortex_south`.`bill`.`tot_amount` = 0);

