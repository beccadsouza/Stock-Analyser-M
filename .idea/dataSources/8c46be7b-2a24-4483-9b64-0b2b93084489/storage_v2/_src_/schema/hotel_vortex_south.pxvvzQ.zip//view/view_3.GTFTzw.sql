create view view_3 as
  select
    count(`hotel_vortex_south`.`staff`.`staff_id`) AS `no_employee`,
    `hotel_vortex_south`.`staff`.`salary`          AS `salary_group`
  from `hotel_vortex_south`.`staff`
  group by `hotel_vortex_south`.`staff`.`salary`;

