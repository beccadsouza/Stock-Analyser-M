create view view_6 as
  select
    `hotel_vortex_south`.`staff`.`name`   AS `name`,
    `hotel_vortex_south`.`staff`.`salary` AS `salary`
  from `hotel_vortex_south`.`staff`
  where ((`hotel_vortex_south`.`staff`.`name` like '%a') and (`hotel_vortex_south`.`staff`.`salary` > 25000))
  union select
          `hotel_vortex_south`.`staff`.`name`   AS `name`,
          `hotel_vortex_south`.`staff`.`salary` AS `salary`
        from `hotel_vortex_south`.`staff`
        where ((`hotel_vortex_south`.`staff`.`name` like '%a') and (`hotel_vortex_south`.`staff`.`salary` < 75000));

