create view sp_query_10 as
  select
    year(`hotel_vortex_south`.`orders`.`order_timestamp`) AS `YYYY`,
    count(`hotel_vortex_south`.`orders`.`order_id`)       AS `COUNTT`
  from `hotel_vortex_south`.`orders`
  group by `hotel_vortex_south`.`orders`.`order_timestamp`;

