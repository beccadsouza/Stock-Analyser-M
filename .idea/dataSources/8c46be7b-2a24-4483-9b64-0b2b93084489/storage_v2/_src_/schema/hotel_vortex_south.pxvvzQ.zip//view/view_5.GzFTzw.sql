create view view_5 as
  select
    `b`.`bill_id`         AS `bill_id`,
    `b`.`tot_amount`      AS `tot_amount`,
    `o`.`order_timestamp` AS `order_timestamp`
  from (`hotel_vortex_south`.`bill` `b`
    join `hotel_vortex_south`.`orders` `o` on ((`b`.`bill_id` = `o`.`bill_id`)))
  where ((`o`.`order_timestamp` between '2011-06-12 01:00:00' and '2013-08-12 12:00:00') and
         (`b`.`tot_amount` in (560, 840, 5780)));

